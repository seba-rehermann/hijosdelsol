/**
 * 🌞 HIJOS DEL SOL - Data Manager
 * Sistema de gestión de datos que funciona online sin backend
 * Usa GitHub como "base de datos" para persistencia
 */

class DataManager {
    constructor() {
        this.storageKey = 'hijosdelsol_cms_data';
        this.githubConfig = {
            // Configuración para usar GitHub como "base de datos"
            owner: 'tu-usuario', // Cambiar por tu usuario de GitHub
            repo: 'hijos-del-sol-data', // Repositorio para datos
            branch: 'main',
            token: null // Se configurará después
        };
        
        this.defaultData = this.getDefaultData();
        this.currentData = {};
        
        this.init();
    }
    
    async init() {
        console.log('🔄 Inicializando Data Manager...');
        
        // Cargar datos desde múltiples fuentes
        await this.loadData();
        
        // Configurar auto-guardado
        this.setupAutoSave();
        
        console.log('✅ Data Manager inicializado');
    }
    
    async loadData() {
        // Intentar cargar desde diferentes fuentes en orden de prioridad
        let dataLoaded = false;
        
        // 1. Intentar desde URL (para compartir configuraciones)
        if (this.loadFromURL()) {
            dataLoaded = true;
            console.log('📁 Datos cargados desde URL');
        }
        
        // 2. Intentar desde localStorage
        if (!dataLoaded && this.loadFromStorage()) {
            dataLoaded = true;
            console.log('📁 Datos cargados desde localStorage');
        }
        
        // 3. Intentar desde GitHub (si está configurado)
        if (!dataLoaded && await this.loadFromGitHub()) {
            dataLoaded = true;
            console.log('📁 Datos cargados desde GitHub');
        }
        
        // 4. Usar datos por defecto
        if (!dataLoaded) {
            this.currentData = { ...this.defaultData };
            console.log('📁 Usando datos por defecto');
        }
        
        // Guardar en localStorage como backup
        this.saveToStorage();
        
        // Disparar evento de datos cargados
        this.triggerDataUpdate();
    }
    
    loadFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        const encodedData = urlParams.get('data');
        
        if (encodedData) {
            try {
                const decodedData = atob(encodedData);
                this.currentData = JSON.parse(decodedData);
                return true;
            } catch (e) {
                console.warn('⚠️ Error cargando datos desde URL:', e);
            }
        }
        
        return false;
    }
    
    loadFromStorage() {
        const savedData = localStorage.getItem(this.storageKey);
        if (savedData) {
            try {
                this.currentData = JSON.parse(savedData);
                return true;
            } catch (e) {
                console.warn('⚠️ Error cargando datos desde localStorage:', e);
            }
        }
        return false;
    }
    
    async loadFromGitHub() {
        if (!this.githubConfig.token) return false;
        
        try {
            const url = `https://api.github.com/repos/${this.githubConfig.owner}/${this.githubConfig.repo}/contents/data.json`;
            const response = await fetch(url, {
                headers: {
                    'Authorization': `token ${this.githubConfig.token}`,
                    'Accept': 'application/vnd.github.v3+json'
                }
            });
            
            if (response.ok) {
                const fileData = await response.json();
                const content = atob(fileData.content);
                this.currentData = JSON.parse(content);
                return true;
            }
        } catch (e) {
            console.warn('⚠️ Error cargando datos desde GitHub:', e);
        }
        
        return false;
    }
    
    saveToStorage() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.currentData));
            console.log('💾 Datos guardados en localStorage');
        } catch (e) {
            console.error('❌ Error guardando en localStorage:', e);
        }
    }
    
    async saveToGitHub() {
        if (!this.githubConfig.token) return false;
        
        try {
            const content = btoa(JSON.stringify(this.currentData, null, 2));
            const url = `https://api.github.com/repos/${this.githubConfig.owner}/${this.githubConfig.repo}/contents/data.json`;
            
            // Primero obtener el SHA del archivo actual (si existe)
            let sha = null;
            try {
                const currentFile = await fetch(url, {
                    headers: {
                        'Authorization': `token ${this.githubConfig.token}`,
                        'Accept': 'application/vnd.github.v3+json'
                    }
                });
                if (currentFile.ok) {
                    const fileData = await currentFile.json();
                    sha = fileData.sha;
                }
            } catch (e) {
                // El archivo no existe, se creará nuevo
            }
            
            const body = {
                message: `Update CMS data - ${new Date().toISOString()}`,
                content: content,
                branch: this.githubConfig.branch
            };
            
            if (sha) {
                body.sha = sha;
            }
            
            const response = await fetch(url, {
                method: 'PUT',
                headers: {
                    'Authorization': `token ${this.githubConfig.token}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });
            
            if (response.ok) {
                console.log('✅ Datos guardados en GitHub');
                return true;
            }
        } catch (e) {
            console.error('❌ Error guardando en GitHub:', e);
        }
        
        return false;
    }
    
    setupAutoSave() {
        // Auto-guardar cada 30 segundos si hay cambios
        setInterval(() => {
            this.saveToStorage();
        }, 30000);
        
        // Guardar antes de cerrar la página
        window.addEventListener('beforeunload', () => {
            this.saveToStorage();
        });
    }
    
    // API pública para el CMS
    getData() {
        return { ...this.currentData };
    }
    
    updateData(newData) {
        this.currentData = { ...this.currentData, ...newData };
        this.saveToStorage();
        this.triggerDataUpdate();
        
        // Auto-guardar en GitHub si está configurado
        if (this.githubConfig.token) {
            this.saveToGitHub();
        }
        
        console.log('📝 Datos actualizados');
    }
    
    setProduct(productId, productData) {
        if (!this.currentData.products) {
            this.currentData.products = {};
        }
        this.currentData.products[productId] = { ...productData, id: productId };
        this.updateData(this.currentData);
    }
    
    setCeremony(ceremonyId, ceremonyData) {
        if (!this.currentData.ceremonies) {
            this.currentData.ceremonies = {};
        }
        this.currentData.ceremonies[ceremonyId] = { ...ceremonyData, id: ceremonyId };
        this.updateData(this.currentData);
    }
    
    setContent(contentType, contentData) {
        if (!this.currentData.content) {
            this.currentData.content = {};
        }
        this.currentData.content[contentType] = contentData;
        this.updateData(this.currentData);
    }
    
    triggerDataUpdate() {
        // Disparar evento personalizado para notificar cambios
        const event = new CustomEvent('cmsDataUpdate', {
            detail: { data: this.currentData }
        });
        document.dispatchEvent(event);
        
        // También actualizar el sitio web directamente
        if (typeof updatePageFromCMS === 'function') {
            // Simular el formato que espera la función existente
            window.cmsData = this.currentData;
            updatePageFromCMS();
        }
    }
    
    exportData() {
        const dataToExport = {
            ...this.currentData,
            exportDate: new Date().toISOString(),
            version: '2.1'
        };
        
        const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `hijos-del-sol-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        return dataToExport;
    }
    
    importData(jsonData) {
        try {
            const importedData = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
            
            if (importedData.products || importedData.ceremonies || importedData.content) {
                this.currentData = { ...this.defaultData, ...importedData };
                this.updateData(this.currentData);
                return true;
            }
        } catch (e) {
            console.error('❌ Error importando datos:', e);
        }
        return false;
    }
    
    generateShareURL() {
        const encodedData = btoa(JSON.stringify(this.currentData));
        const baseURL = window.location.origin + window.location.pathname;
        return `${baseURL}?data=${encodedData}`;
    }
    
    resetData() {
        this.currentData = { ...this.defaultData };
        this.updateData(this.currentData);
        console.log('🔄 Datos reseteados');
    }
    
    getDefaultData() {
        return {
            products: {
                "nukini": {
                    id: "nukini",
                    name: "Rapé Nukini",
                    price: 2500,
                    emoji: "🌿",
                    imageType: "emoji",
                    imageUrl: "",
                    description: "Rapé tradicional de la tribu Nukini, conocido por su efecto clarificador y equilibrante.",
                    features: ["Claridad Mental", "Conexión Espiritual"],
                    stock: "En Stock"
                },
                "huni-kuin": {
                    id: "huni-kuin",
                    name: "Rapé Huni Kuin",
                    price: 2800,
                    emoji: "🍃",
                    imageType: "emoji",
                    imageUrl: "",
                    description: "Medicina sagrada de la tribu Huni Kuin del Acre, Brasil. Elaborado con plantas medicinales.",
                    features: ["Introspección", "Sanación"],
                    stock: "En Stock"
                }
            },
            ceremonies: {
                "luna-nueva": {
                    id: "luna-nueva",
                    name: "Ceremonia de Luna Nueva",
                    date: "2025-03-15",
                    time: "16:00 - 20:00 hs",
                    location: "Centro Ceremonial Pachamama, Buenos Aires",
                    facilitator: "Shamán Carlos Nukini",
                    description: "Ceremonia especial de luna nueva para liberar lo que ya no sirve y manifestar nuevas intenciones.",
                    imageUrl: "",
                    price: 8500,
                    spots: 12
                }
            },
            content: {
                navigation: {
                    brand: '☀️ Hijos del Sol',
                    links: {
                        inicio: 'Inicio',
                        productos: 'Productos',
                        ceremonias: 'Ceremonias',
                        nosotros: 'Nosotros',
                        contacto: 'Contacto'
                    }
                },
                hero: {
                    title: '☀️ Hijos del Sol',
                    subtitle: 'Conecta con la medicina ancestral en un espacio sagrado de sanación, transformación y comunidad',
                    button1: 'Explorar Productos',
                    button2: 'Ver Ceremonias',
                    background_image: '',
                    use_gradient: true
                },
                products_section: {
                    title: '🌿 Nuestros Productos Sagrados',
                    subtitle: 'Medicina ancestral de las tradiciones amazónicas'
                },
                ceremonies_section: {
                    title: '🕉️ Ceremonias Sagradas',
                    subtitle: 'Espacios de sanación y transformación'
                },
                about: {
                    title: '🌞 Nuestra Misión',
                    text1: 'Somos Hijos del Sol, una comunidad dedicada a preservar y compartir las tradiciones ancestrales de medicina sagrada.',
                    text2: 'Nuestro compromiso es crear espacios seguros de sanación donde cada persona pueda conectar con su esencia.',
                    values: {
                        value1: { icon: '🙏', text: 'Respeto Ancestral' },
                        value2: { icon: '💚', text: 'Sanación Auténtica' },
                        value3: { icon: '🌱', text: 'Crecimiento Espiritual' }
                    },
                    placeholder: { icon: '🌞', text: 'Espacio de medicina sagrada' }
                },
                contact_section: {
                    title: '📞 Conecta con Nosotros',
                    info_title: 'Información de Contacto',
                    form_title: 'Envíanos un Mensaje',
                    form_placeholders: {
                        name: 'Tu nombre',
                        email: 'Tu email',
                        phone: 'Tu teléfono',
                        message: 'Tu mensaje o consulta'
                    },
                    form_button: 'Enviar Mensaje'
                },
                footer: {
                    brand_text: 'Medicina ancestral con respeto y tradición',
                    links_title: 'Enlaces',
                    contact_title: 'Contacto',
                    copyright: '© 2025 Hijos del Sol. Todos los derechos reservados.'
                },
                cart: {
                    title: '🛒 Carrito de Compras',
                    total_text: 'Total',
                    buttons: {
                        clear: '🗑️ Vaciar',
                        continue: 'Seguir Comprando',
                        checkout: 'Finalizar Compra'
                    },
                    empty_message: 'Tu carrito está vacío',
                    cart_button: '🛒'
                },
                page_title: '☀️ Hijos del Sol - Ceremonias Sagradas'
            },
            contact: {
                phone: '+54 11 2345-6789',
                email: 'medicina@hijosdelsol.com',
                address: 'Buenos Aires, Argentina',
                instagram: '@hijosdelsol.ceremonias',
                whatsapp: '5491123456789'
            }
        };
    }
}

// Instancia global
window.dataManager = new DataManager();

// Exportar para compatibilidad
window.getCMSData = () => window.dataManager.getData();
window.updateCMSData = (data) => window.dataManager.updateData(data);

console.log('🌞 Data Manager cargado correctamente');
