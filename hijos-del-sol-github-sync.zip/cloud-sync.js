/**
 * 🌞 HIJOS DEL SOL - Cloud Sync System
 * Sistema de sincronización en la nube
 * Los cambios se ven en todos los dispositivos
 */

class CloudSyncManager {
    constructor() {
        this.storageKey = 'hijosdelsol_cms_data';
        this.defaultData = this.getDefaultData();
        this.currentData = {};
        this.lastSync = null;
        this.isOnline = navigator.onLine;
        
        // Configuración simple usando JSONBin (gratis)
        this.cloudStorageUrl = 'https://api.jsonbin.io/v3/b';
        this.binId = this.getBinId();
        this.apiKey = this.getApiKey();
        
        this.init();
    }
    
    async init() {
        console.log('🔄 Inicializando Cloud Sync Manager...');
        
        // Detectar cambios de conectividad
        window.addEventListener('online', () => {
            this.isOnline = true;
            console.log('🌐 Conectado a internet');
            this.syncFromCloud();
        });
        
        window.addEventListener('offline', () => {
            this.isOnline = false;
            console.log('📱 Modo offline');
        });
        
        // Cargar datos con prioridad de la nube
        await this.loadData();
        
        // Auto-sync cada 60 segundos
        setInterval(() => {
            if (this.isOnline) {
                this.syncFromCloud();
            }
        }, 60000);
        
        console.log('✅ Cloud Sync Manager inicializado');
    }
    
    async loadData() {
        console.log('📁 Cargando datos...');
        let dataLoaded = false;
        
        // 1. Intentar cargar desde la nube primero
        if (this.isOnline) {
            const cloudData = await this.loadFromCloud();
            if (cloudData) {
                this.currentData = cloudData;
                dataLoaded = true;
                console.log('☁️ Datos cargados desde la nube');
            }
        }
        
        // 2. Fallback a localStorage
        if (!dataLoaded && this.loadFromLocal()) {
            dataLoaded = true;
            console.log('📱 Datos cargados desde dispositivo local');
        }
        
        // 3. Usar datos por defecto
        if (!dataLoaded) {
            this.currentData = { ...this.defaultData };
            console.log('🆕 Usando datos por defecto');
        }
        
        // Guardar localmente como backup
        this.saveToLocal();
        
        // Disparar evento de datos cargados
        this.triggerDataUpdate();
    }
    
    async loadFromCloud() {
        if (!this.binId) return null;
        
        try {
            const response = await fetch(`${this.cloudStorageUrl}/${this.binId}/latest`);
            
            if (response.ok) {
                const result = await response.json();
                return result.record;
            }
        } catch (e) {
            console.warn('⚠️ Error cargando desde la nube:', e);
        }
        
        return null;
    }
    
    loadFromLocal() {
        const savedData = localStorage.getItem(this.storageKey);
        if (savedData) {
            try {
                this.currentData = JSON.parse(savedData);
                return true;
            } catch (e) {
                console.warn('⚠️ Error cargando datos locales:', e);
            }
        }
        return false;
    }
    
    async saveToCloud(data = this.currentData) {
        if (!this.isOnline) {
            console.log('📱 Sin conexión - guardando solo localmente');
            this.saveToLocal(data);
            return false;
        }
        
        console.log('☁️ Guardando en la nube...');
        
        try {
            const dataToSave = {
                ...data,
                lastUpdated: new Date().toISOString(),
                device: navigator.userAgent.includes('Mobile') ? 'Mobile' : 'Desktop'
            };
            
            const url = this.binId ? 
                `${this.cloudStorageUrl}/${this.binId}` : 
                this.cloudStorageUrl;
            
            const response = await fetch(url, {
                method: this.binId ? 'PUT' : 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Bin-Name': 'hijos-del-sol-cms'
                },
                body: JSON.stringify(dataToSave)
            });
            
            if (response.ok) {
                const result = await response.json();
                
                // Guardar el bin ID si es nuevo
                if (!this.binId && result.metadata?.id) {
                    this.setBinId(result.metadata.id);
                }
                
                this.lastSync = new Date().toISOString();
                console.log('✅ Guardado en la nube');
                return true;
            }
        } catch (e) {
            console.warn('⚠️ Error guardando en la nube:', e);
        }
        
        // Siempre guardar localmente como backup
        this.saveToLocal(data);
        return false;
    }
    
    saveToLocal(data = this.currentData) {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(data));
            localStorage.setItem(this.storageKey + '_timestamp', new Date().toISOString());
        } catch (e) {
            console.error('❌ Error guardando localmente:', e);
        }
    }
    
    // API pública
    getData() {
        return { ...this.currentData };
    }
    
    async updateData(newData) {
        this.currentData = { ...this.currentData, ...newData };
        
        // Guardar localmente inmediatamente
        this.saveToLocal();
        
        // Intentar guardar en la nube
        const cloudSaved = await this.saveToCloud();
        
        // Disparar actualización
        this.triggerDataUpdate();
        
        console.log('📝 Datos actualizados y sincronizados');
        
        return cloudSaved;
    }
    
    async syncFromCloud() {
        const cloudData = await this.loadFromCloud();
        if (cloudData) {
            // Verificar si los datos de la nube son más recientes
            const localTimestamp = localStorage.getItem(this.storageKey + '_timestamp');
            const cloudTimestamp = cloudData.lastUpdated;
            
            if (!localTimestamp || (cloudTimestamp && new Date(cloudTimestamp) > new Date(localTimestamp))) {
                console.log('🔄 Sincronizando datos más recientes desde la nube');
                this.currentData = cloudData;
                this.saveToLocal();
                this.triggerDataUpdate();
                
                // Mostrar notificación si estamos en el admin
                if (typeof showMessage === 'function') {
                    showMessage('🔄 Datos sincronizados desde la nube', 'info');
                }
                
                return true;
            }
        }
        return false;
    }
    
    triggerDataUpdate() {
        // Disparar evento personalizado
        const event = new CustomEvent('cmsDataUpdate', {
            detail: { 
                data: this.currentData,
                source: 'cloud-sync',
                timestamp: new Date().toISOString()
            }
        });
        document.dispatchEvent(event);
        
        // Actualizar página si la función existe
        if (typeof updatePageFromCMS === 'function') {
            window.cmsData = this.currentData;
            updatePageFromCMS();
        }
        
        // Actualizar productos y ceremonias si las funciones existen
        if (typeof renderProductsFromCMS === 'function') {
            renderProductsFromCMS();
        }
        
        if (typeof renderCeremoniesFromCMS === 'function') {
            renderCeremoniesFromCMS();
        }
    }
    
    // Utilidades para el storage en la nube
    getBinId() {
        return localStorage.getItem('cloud_bin_id');
    }
    
    setBinId(id) {
        localStorage.setItem('cloud_bin_id', id);
        this.binId = id;
    }
    
    // Función para forzar sincronización
    async forceSyncToCloud() {
        const result = await this.saveToCloud();
        if (result) {
            if (typeof showMessage === 'function') {
                showMessage('✅ Datos sincronizados exitosamente con la nube', 'success');
            }
        } else {
            if (typeof showMessage === 'function') {
                showMessage('⚠️ Error sincronizando con la nube. Los datos se guardaron localmente.', 'warning');
            }
        }
        return result;
    }
    
    getDefaultData() {
        return {
            products: {
                "nukini": {
                    id: "nukini",
                    name: "Rapé Nukini",
                    price: 2500,
                    emoji: "🌿",
                    imageType: "emoji",
                    imageUrl: "",
                    description: "Rapé tradicional de la tribu Nukini, conocido por su efecto clarificador y equilibrante.",
                    features: ["Claridad Mental", "Conexión Espiritual"],
                    stock: "En Stock"
                },
                "huni-kuin": {
                    id: "huni-kuin",
                    name: "Rapé Huni Kuin",
                    price: 2800,
                    emoji: "🍃",
                    imageType: "emoji",
                    imageUrl: "",
                    description: "Medicina sagrada de la tribu Huni Kuin del Acre, Brasil. Elaborado con plantas medicinales.",
                    features: ["Introspección", "Sanación"],
                    stock: "En Stock"
                }
            },
            ceremonies: {
                "luna-nueva": {
                    id: "luna-nueva",
                    name: "Ceremonia de Luna Nueva",
                    date: "2025-03-15",
                    time: "16:00 - 20:00 hs",
                    location: "Centro Ceremonial Pachamama, Buenos Aires",
                    facilitator: "Shamán Carlos Nukini",
                    description: "Ceremonia especial de luna nueva para liberar lo que ya no sirve y manifestar nuevas intenciones.",
                    imageUrl: "",
                    price: 8500,
                    spots: 12
                }
            },
            content: {
                navigation: {
                    brand: '☀️ Hijos del Sol',
                    links: {
                        inicio: 'Inicio',
                        productos: 'Productos',
                        ceremonias: 'Ceremonias',
                        nosotros: 'Nosotros',
                        contacto: 'Contacto'
                    }
                },
                hero: {
                    title: '☀️ Hijos del Sol',
                    subtitle: 'Conecta con la medicina ancestral en un espacio sagrado de sanación, transformación y comunidad',
                    button1: 'Explorar Productos',
                    button2: 'Ver Ceremonias',
                    background_image: '',
                    use_gradient: true
                },
                products_section: {
                    title: '🌿 Nuestros Productos Sagrados',
                    subtitle: 'Medicina ancestral de las tradiciones amazónicas'
                },
                ceremonies_section: {
                    title: '🕉️ Ceremonias Sagradas',
                    subtitle: 'Espacios de sanación y transformación'
                },
                about: {
                    title: '🌞 Nuestra Misión',
                    text1: 'Somos Hijos del Sol, una comunidad dedicada a preservar y compartir las tradiciones ancestrales de medicina sagrada.',
                    text2: 'Nuestro compromiso es crear espacios seguros de sanación donde cada persona pueda conectar con su esencia.',
                    values: {
                        value1: { icon: '🙏', text: 'Respeto Ancestral' },
                        value2: { icon: '💚', text: 'Sanación Auténtica' },
                        value3: { icon: '🌱', text: 'Crecimiento Espiritual' }
                    },
                    placeholder: { icon: '🌞', text: 'Espacio de medicina sagrada' }
                },
                contact_section: {
                    title: '📞 Conecta con Nosotros',
                    info_title: 'Información de Contacto',
                    form_title: 'Envíanos un Mensaje',
                    form_placeholders: {
                        name: 'Tu nombre',
                        email: 'Tu email',
                        phone: 'Tu teléfono',
                        message: 'Tu mensaje o consulta'
                    },
                    form_button: 'Enviar Mensaje'
                },
                footer: {
                    brand_text: 'Medicina ancestral con respeto y tradición',
                    links_title: 'Enlaces',
                    contact_title: 'Contacto',
                    copyright: '© 2025 Hijos del Sol. Todos los derechos reservados.'
                },
                cart: {
                    title: '🛒 Carrito de Compras',
                    total_text: 'Total',
                    buttons: {
                        clear: '🗑️ Vaciar',
                        continue: 'Seguir Comprando',
                        checkout: 'Finalizar Compra'
                    },
                    empty_message: 'Tu carrito está vacío',
                    cart_button: '🛒'
                },
                page_title: '☀️ Hijos del Sol - Ceremonias Sagradas'
            },
            contact: {
                phone: '+54 11 2345-6789',
                email: 'medicina@hijosdelsol.com',
                address: 'Buenos Aires, Argentina',
                instagram: '@hijosdelsol.ceremonias',
                whatsapp: '5491123456789'
            },
            lastUpdated: new Date().toISOString(),
            version: '3.0-cloud-sync'
        };
    }
}

// Instancia global
window.cloudSyncManager = new CloudSyncManager();

// API de compatibilidad
window.getCMSData = () => window.cloudSyncManager.getData();
window.updateCMSData = (data) => window.cloudSyncManager.updateData(data);
window.forceSyncToCloud = () => window.cloudSyncManager.forceSyncToCloud();

console.log('☁️ Cloud Sync Manager cargado correctamente');
